package jUnitTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class addstring {

	@Test
	void test() {
		jUnitfunction junit=new jUnitfunction();
		String result=junit.addStrings("sailesh", "sweety");
		assertEquals("saileshsweety",result);
	}

}
